﻿using Microsoft.AspNetCore.Mvc;
using MvcMovie.Data;

public class MoviesController : Controller
{
    private readonly MvcMovieContext _context;

    public MoviesController(MvcMovieContext context)
    {
        _context = context;
    }
}
